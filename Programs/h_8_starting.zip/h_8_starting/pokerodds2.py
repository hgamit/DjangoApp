#
# H8-3: pokerodds2.py
#
#   Starting code H8-3
#
# start with your pokerodds.py code from Lab 9 (L9-4)
#

