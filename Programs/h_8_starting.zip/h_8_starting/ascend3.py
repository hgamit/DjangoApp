#
# HW 8-1: ascend3.py
#
#   Starting code for program that prints out all 3 digit ints
#		abc where a < b < c
#

