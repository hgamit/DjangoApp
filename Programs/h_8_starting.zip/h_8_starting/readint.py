#
# H8-4: readint.py
#
#   Starting code H8-4
#

def read_int():
	'''
	read int from user and return;
	handle exceptions to defend against invalid ints
	:return:
	'''
	pass





