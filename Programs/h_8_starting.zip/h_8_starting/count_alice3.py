#
# H8-2: count_alice3.py
#
#   Starting code H8-2
#

# start with your H8-2 count_alice2 and continue...


