#
# HW 8-5: inventory.py
#
#   Starting code for a simple inventory tracking program using
#       dictionaries.
#

def getCommand():
    command = input("Enter command: ")
    return command

def addToInventory(dict):
    pass

def viewInventory(dict):
    pass

def main():

    print ("Welcome to StuffMaster, v.0.47")

    inventory = {} # empty dictionary

    while True: # get command, process command; quit when selected below
        pass

        # Get the command,
        #
        # Call the appropriate function based on command
        #
        # If unknown command, complain and prompt for reentry

    # here, we're quitting

    print ("Quitting. Final version of inventory is:")

    # print out final version of inventory

    print ("Exiting...")

main()
