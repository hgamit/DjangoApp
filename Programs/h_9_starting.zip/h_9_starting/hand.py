#
# H9-3:
#
#   hand.py
#

class Hand():
	'''
	Collection of Cards dealt from Deck
	'''
	def __init__(self):
		'''
		Initialzes new Hand by adding empty _cards list
		'''
		pass

	def addCard(self,cardToAdd):
		'''
		Adds cardToAdd to this Hand
		:param cardToAdd:
		'''
		pass

	def __str__(self):
		'''
		Return string describing all cards in hand
		'''
		pass


def main():
	'''
	Create new Deck, shuffle it, create new Hand,
		deal top 5 Cards of Deck into it,
		then print "stringified" Hand
	'''
	pass

main()