#
# H9-2:
#
#   bjackodds.py
#

TRIALS = 10000

def main():
	'''
	Repeat the following of TRIALS
	'''

	pass
