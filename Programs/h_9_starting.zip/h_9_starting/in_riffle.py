#
# H9-5:
#
#   in_riffle.py
#
#   Note provided deck.py has outRiffle() as done in Lab 10
#		Modify this within Deck, adding new method inRiffle().
#

